<?php return array (
  'web_title' => '后盾Blog系统',
  'web_count' => '百度统计',
  'web_status' => '0',
  'seo_title' => '后盾网 人人做后盾',
  'keywords' => '北京php培训,php视频教程,php培训,php基础视频,php实例视频,lamp视频教程',
  'description' => '后盾网顶尖PHP培训，最专业的网站开发php培训，小班化授课，全程实战！业内顶级北京php培训讲师亲自授课，千余课时php独家视频教程免费下载，数百G原创视频资源，实力不容造假！抢座热线：400-682-3231',
  'copyright' => 'Design by 后盾网 <a href="http://www.houdunwang.com" target="_blank">http://www.houdunwang.com</a>',
);